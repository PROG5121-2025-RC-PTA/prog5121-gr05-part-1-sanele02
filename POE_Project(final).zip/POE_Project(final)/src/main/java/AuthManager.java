import java.util.Scanner;

import java.util.Scanner;

public class AuthManager {

    private String userName;
    private String userPhoneNumber;
    private String userPassword;
    private static String[] arrUserNames = new String[100];
    private static String[] arrPasswords = new String[100];
    private static String[] arrPhoneNumbers = new String[100];
    private static int userCount = 0;

    // Constructor
    public AuthManager() {
        this.userName = userName;
        this.userPhoneNumber = userPhoneNumber;
        this.userPassword = userPassword;
    }

    public void createAccount() {
        Scanner userInput = new Scanner(System.in);
        String message;

        System.out.println("----------------------------------------");
        System.out.println("Create New Account");

        // Username capture & check
        do {
            System.out.println("Enter user Name (username must contain at least 5 characters & an underscore):");
            userName = userInput.nextLine();
            message = checkUserName(userName);
            System.out.println(message);
        } while (!message.equals("Username successfully captured"));

        // Phone number capture & check
        do {
            System.out.println("Enter user Phone Number (must contain the international country code, e.g. +27):");
            userPhoneNumber = userInput.nextLine();

            if (checkCellPhoneNumber(userPhoneNumber)) {
                System.out.println("Cell phone number successfully added");
            } else {
                System.out.println("Cell phone number incorrectly formatted or does not contain international code");
            }
        } while (!checkCellPhoneNumber(userPhoneNumber));

        // Password capture & check
        do {
            System.out.println("Enter user Password (at least 8 characters, 1 capital letter, 1 number, 1 special character):");
            userPassword = userInput.nextLine();
            if (checkPasswordComplexity(userPassword)) {
                System.out.println("Password successfully captured!");
            } else {
                System.out.println("Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number and a special character.");
            }
        } while (!checkPasswordComplexity(userPassword));

        // Register user & show message
        String registerMessage = registerUser(userName, userPassword, userPhoneNumber);
        System.out.println(registerMessage);


        // LOGIN AFTER REGISTRATION
        System.out.println("\n Please log in to confirm your account:");
        String enteredUsername, enteredPassword;

        do {
            System.out.print("Enter username: ");
            enteredUsername = userInput.nextLine();

            System.out.print("Enter password: ");
            enteredPassword = userInput.nextLine();

            if (loginUser(enteredUsername, enteredPassword)) {
                System.out.println("Login successful! Welcome, " + enteredUsername + ".");
                sendMessages.start();// start messaging // calling the sendMessage class
                break;
            } else {
                System.out.println("Login failed. Please try again.");
            }
        } while (true);
    }

    // Username check
    public static String checkUserName(String username) {
        if (username.contains("_") && username.length() <= 5) {
            return "Username successfully captured";
        } else {
            return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.";
        }
    }

    // Password check
    public static boolean checkPasswordComplexity(String password) {
        boolean hasUppercase = false;
        boolean hasDigit = false;
        boolean hasSpecialChar = false;

        if (password.length() < 8) {
            return false;
        }

        for (char ch : password.toCharArray()) {
            if (Character.isUpperCase(ch)) hasUppercase = true;
            else if (Character.isDigit(ch)) hasDigit = true;
            else if (!Character.isLetterOrDigit(ch)) hasSpecialChar = true;
        }

        return hasUppercase && hasDigit && hasSpecialChar;
    }

    // Phone number check
    public static boolean checkCellPhoneNumber(String phoneNumber) {
        return phoneNumber != null && phoneNumber.matches("^\\+27\\d{9}$");
        //return phoneNumber.matches("\\+27\\d{9}");
    }

    // Register user
    public static String registerUser(String username, String password, String phoneNumber) {

        boolean validname = username.contains("_") && username.length() <= 5;
        boolean validPass = checkPasswordComplexity(password);
        boolean validPhone = phoneNumber.matches("\\+27\\d{9}");

        if (!validname) {
            return "Username is not correctly formatted – must contain an underscore and be no more than 5 characters.";

        }
        else if (!validPass) {
            return "Password is not correctly formatted – must be at least 8 characters long, include a capital letter, a number, and a special character.";
        }
        else if (!validPhone) {
            return "Cell phone number incorrectly formatted or does not contain international code.";
        }


        // Save to arrays
        arrUserNames[userCount] = username;
        arrPasswords[userCount] = password;
        arrPhoneNumbers[userCount] = phoneNumber;
        userCount++;

        return "  Registration successful!  " ;
    }




    //-------------
    // Login verification
    public static boolean loginUser(String enteredUsername, String enteredPassword) {
        for (int i = 0; i < userCount; i++) {
            if (arrUserNames[i].equals(enteredUsername) && arrPasswords[i].equals(enteredPassword)) {
                return true;
            }
        }
        return false;
    }

    // Return login status message
    public static String returnLoginStatus(String enteredUsername, String enteredPassword) {
        boolean isLoginSuccessful = loginUser(enteredUsername, enteredPassword);
        if (isLoginSuccessful) {
            sendMessages.start();// start messaging // calling the sendMessage class
            return "Login successful! Welcome, " + enteredUsername + ".";

        } else {
            return "Login failed. Please check your username and password.";
        }
    }
}


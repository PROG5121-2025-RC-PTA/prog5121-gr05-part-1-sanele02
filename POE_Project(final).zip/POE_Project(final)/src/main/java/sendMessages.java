import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.*;
import java.time.*;
import java.time.format.*;
import org.json.*;
import java.nio.file.*;

public class sendMessages {
    // Arrays for all message types
    private static List<Message> sentMessages = new ArrayList<>();
    private static List<Message> disregardedMessages = new ArrayList<>();
    private static List<Message> storedMessages = new ArrayList<>();
    private static List<String> messageHashes = new ArrayList<>();
    private static List<String> messageIDs = new ArrayList<>();

    // JSON configuration
    private static final String JSON_FILE = "messages.json";

    public static void start(){
        new sendMessages().startMenu();
    }

    public static void main(String[] args) {
        loadFromJson();
        new sendMessages().startMenu();
    }

    public void startMenu() {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n=== QuickChat Menu ===");
            System.out.println("1. Send Message(s)");
            System.out.println("2. Message Reports");
            System.out.println("3. Message Statistics");
            System.out.println("4. Logout");
            System.out.print("Choose an option: ");

            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    sendMessagesFlow(scanner);
                    break;
                case 2:
                    reportsMenu(scanner);
                    break;
                case 3:
                    //displayStatistics();//error
                    break;
                case 4:
                    System.out.println("Logging out...");
                    break;

                default:
                    System.out.println("Invalid option!");
            }
        }
    }

    private void sendMessagesFlow(Scanner scanner) {
        System.out.print("Enter recipient phone (+27xxxxxxxxx): ");
        String recipient = scanner.nextLine();

        if (checkRecipientCell(recipient) <= 0) {
            System.out.println("Invalid phone format!");
            return;
        }

        System.out.print("How many messages? ");
        int count = scanner.nextInt();
        scanner.nextLine();

        for (int i = 0; i < count; i++) {
            System.out.printf("Message %d/%d: ", i+1, count);
            String content = scanner.nextLine();

            Message msg = new Message(
                    UUID.randomUUID().toString().substring(0, 10),
                    recipient,
                    content
            );

            System.out.println("1. Send  2. Store  3. Disregard");
            int action = scanner.nextInt();
            scanner.nextLine();

            String result ;
            switch (action) {
                case 1 :
                    result=msg.send();
                    break;
                case 2 :
                    result=msg.store();
                    break;
                case 3 :
                    result=msg.disregard();
                    break;
                default :
                    System.out.println("Invalid action!");
                    result = "Operation failed! Please try again.";
            };
            System.out.println(result);
        }
    }

    private void reportsMenu(Scanner scanner) {
        System.out.println("\n=== Reports ===");
        System.out.println("1. All Recipients");
        System.out.println("2. Longest Message");
        System.out.println("3. Search by ID");
        //System.out.println("4. Search by Recipient");
        System.out.println("4. Delete by Hash");
        System.out.println("5. Full Message Report");
        System.out.print("Choose report: ");

        int choice = scanner.nextInt();
        scanner.nextLine();

        switch (choice) {
            case 1:
                displayAllRecipients();
                break;
            case 2 :
                displayLongestMessage();
                break;
            case 3 :
                searchById(scanner);
                break;
            //case 4 -> searchByRecipient(scanner);
            case 4 :
                deleteByHash(scanner);
                break;
            case 5 :
                fullMessageReport();
                break;
            default :
                System.out.println("Invalid option!");
        }
    }

    // ===== Core Functionality Methods =====
    public static int checkRecipientCell(String phone) {
        return (phone != null && phone.matches("^\\+27\\d{9}$")) ? phone.length() : -1;
    }

    // ===== Reporting Methods =====
    private void displayAllRecipients() {
        System.out.println("\nAll Recipients:");
        sentMessages.stream()
                .map(Message::getRecipient)
                .distinct()
                .forEach(System.out::println);
    }

    private void displayLongestMessage() {
        sentMessages.stream()
                .max(Comparator.comparingInt(m -> m.getContent().length()))
                .ifPresentOrElse(
                        msg -> System.out.printf(
                                "\nLongest Message (%d chars):\n%s\n",
                                msg.getContent().length(),
                                msg.getContent()
                        ),
                        () -> System.out.println("No sent messages!")
                );
    }

    private void searchById(Scanner scanner) {
        System.out.print("Enter Message ID: ");
        String id = scanner.nextLine();

        sentMessages.stream()
                .filter(m -> m.getMessageId().equals(id))
                .findFirst()
                .ifPresentOrElse(
                        msg -> System.out.printf(
                                "Found: To %s - %s\n",
                                msg.getRecipient(),
                                msg.getContent()
                        ),
                        () -> System.out.println("Message not found!")
                );
    }

    private void deleteByHash(Scanner scanner) {
        System.out.print("Enter Message Hash: ");
        String hash = scanner.nextLine();

        if (sentMessages.removeIf(m -> m.getHash().equals(hash))) {
            System.out.println("Message deleted!");
        } else {
            System.out.println("Message not found!");
        }
    }

    private void fullMessageReport() {
        System.out.println("\n=== Full Message Report ===");
        System.out.printf("Total Sent: %d\n", sentMessages.size());
        System.out.printf("Total Stored: %d\n", storedMessages.size());
        System.out.printf("Total Disregarded: %d\n", disregardedMessages.size());

        System.out.println("\nRecent Messages:");
        sentMessages.stream()
                .limit(5)
                .forEach(m -> System.out.printf(
                        "[%s] To %s: %.20s...\n",
                        m.getTimestamp(),
                        m.getRecipient(),
                        m.getContent()
                ));
    }

    // ===== JSON Handling =====
    private static void saveToJson() {
        try {
            JSONArray jsonArray = new JSONArray();
            storedMessages.forEach(msg -> jsonArray.put(msg.toJson()));
            Files.writeString(Paths.get(JSON_FILE), jsonArray.toString());
        } catch (Exception e) {
            System.out.println("Error saving messages: " + e.getMessage());
        }
    }

    private static void loadFromJson() {
        try {
            if (!Files.exists(Paths.get(JSON_FILE))) return;

            String content = Files.readString(Paths.get(JSON_FILE));
            JSONArray jsonArray = new JSONArray(content);

            for (int i = 0; i < jsonArray.length(); i++) {
                Message msg = Message.fromJson(jsonArray.getJSONObject(i));
                storedMessages.add(msg);
                messageHashes.add(msg.getHash());
                messageIDs.add(msg.getMessageId());
            }
        } catch (Exception e) {
            System.out.println("Error loading messages: " + e.getMessage());
        }
    }

    // Message Class
        public static class Message {
        private final String messageId;
        private final String recipient;
        private final String content;
        private final String timestamp;
        private boolean sent;
        private String hash;

        public Message(String id, String recipient, String content) {
            this.messageId = id.length() > 10 ? id.substring(0, 10) : id;
            this.recipient = recipient;
            this.content = content;
            this.timestamp = LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_TIME);
            this.hash = createMessageHash();
        }

        public String send() {
            sent = true;
            sentMessages.add(this);
            messageHashes.add(this.hash);
            messageIDs.add(this.messageId);
            return "Message sent to " + recipient;
        }

        public String store() {
            storedMessages.add(this);
            messageHashes.add(this.hash);
            messageIDs.add(this.messageId);
            saveToJson();
            return "Message stored";
        }

        public String disregard() {
            disregardedMessages.add(this);
            return "Message disregarded";
        }

        private String createMessageHash() {
            try {
                MessageDigest digest = MessageDigest.getInstance("SHA-256");
                byte[] hashBytes = digest.digest(content.getBytes());
                StringBuilder hexString = new StringBuilder();
                for (byte b : hashBytes) {
                    hexString.append(String.format("%02x", b));
                }
                return hexString.toString();
            } catch (Exception e) {
                throw new RuntimeException("Hash failed", e);
            }
        }

        public JSONObject toJson() {
            return new JSONObject()
                    .put("id", messageId)
                    .put("recipient", recipient)
                    .put("content", content)
                    .put("hash", hash)
                    .put("timestamp", timestamp)
                    .put("sent", sent);
        }

        public static Message fromJson(JSONObject json) {
            Message msg = new Message(
                    json.getString("id"),
                    json.getString("recipient"),
                    json.getString("content")
            );
            msg.sent = json.getBoolean("sent");
            msg.hash = json.getString("hash");
            return msg;
        }

        // Getters
        public String getMessageId() { return messageId; }
        public String getRecipient() { return recipient; }
        public String getContent() { return content; }
        public String getTimestamp() { return timestamp; }
        public String getHash() { return hash; }
        public boolean isSent() { return sent; }
    }
//part3
    // Add these to your sendMessages class
    public static List<Message> getSentMessages() {
        return sentMessages;
    }

    public static List<Message> getStoredMessages() {
        return storedMessages;
    }

    public static List<Message> getDisregardedMessages() {
        return disregardedMessages;
    }

    public static List<String> getMessageHashes() {
        return messageHashes;
    }

    public static List<String> getMessageIDs() {
        return messageIDs;
    }
}
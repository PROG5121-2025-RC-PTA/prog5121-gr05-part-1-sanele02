import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner userInput = new Scanner(System.in);
        String options;

        //GREETINGS
        System.out.println("Welcome to MyChat Bot! ");
        System.out.println("_________________________________________________");
        System.out.println("Please enter the correct letter (e.g A,B or C)");
        System.out.println("A. Create new account");
        System.out.println("B. Log into an existing account");
        System.out.println("C. Exit the program");
        System.out.print("Please enter a letter: ");
        options = userInput.next().toUpperCase(); // Get user input and make every letter upper case to stop any errors from happening

        // Keep prompting the user until they enter a valid option (A, B, or C)
        label:
        while (true) {

            switch (options) {
                case "A":
                    // Direct to -> AuthManager -> createAccount method
                    AuthManager newCustomer = new AuthManager();
                    newCustomer.createAccount();

                    //break; // Exit the loop if valid input is entered

                    break;
                case "B":
                    // Direct to Log-in function in an existing  class called authManager
                    String loginUserName, loginUserPassword;
                    System.out.println("----------------------------------------");
                    System.out.println("Login to account ");
                    System.out.print("UserName: ");
                    loginUserName = userInput.next();
                    System.out.print("Password: ");
                    loginUserPassword = userInput.next();
                    String loginMessage = AuthManager.returnLoginStatus(loginUserName, loginUserPassword);
                    // Print the result
                    System.out.println(loginMessage);
                    userInput.close();
                    //break; // Exit the loop if valid input is entered

                    break;
                case "C":
                    // Exit the program
                    System.out.println("Exiting the Chat Bot...");
                    break ; // Exit the loop if valid input is entered
                default:
                    // Invalid input,  user must try again
                    System.out.println("Invalid input. Please enter A, B or C.");
                    break;
            }
        }
    }
}
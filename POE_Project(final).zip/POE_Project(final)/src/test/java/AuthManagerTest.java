import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class AuthManagerTest {
    AuthManager auth = new AuthManager();


    @Test
    void checkUserName() {
        //valid data
        String expected = "Username successfully captured";
        String actual = auth.checkUserName("kyl_1");
        assertEquals(expected, actual);

        //invalid data
        String expected2 = "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.";
        String actual2 = auth.checkUserName("kyle!!!!");
        assertEquals(expected2, actual2);



    }

    @Test
    void checkPasswordComplexity() {
        //valid data
        assertTrue(auth.checkPasswordComplexity("Ch&&sec@ke99!"));

        // invalid data
        assertFalse(auth.checkPasswordComplexity("yoH1!"));
    }



    @Test
    void checkCellPhoneNumber() {
        // Valid data
        assertTrue(auth.checkCellPhoneNumber("+27838968976"));

        // Invalid data
        assertFalse(auth.checkCellPhoneNumber("08966553")); // No +27

        //assertFalse(auth.checkCellPhoneNumber(null));



    }


}